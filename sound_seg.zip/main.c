#include "sound_seg.h"
#include <stdio.h>
#include <errno.h>
#include <string.h>

int main() {
    // 创建一个新的音轨
    struct sound_seg* track = tr_init();
    if (!track) {
        printf("Failed to initialize track\n");
        return 1;
    }

    const char* filename = "input.wav";
    // 从WAV文件加载音频
    size_t length;
    printf("Attempting to load file: %s\n", filename);
    
    // 首先检查文件是否可以打开
    FILE* test = fopen(filename, "rb");
    if (!test) {
        printf("Error opening file: %s\n", strerror(errno));
        tr_destroy(track);
        return 1;
    }
    fclose(test);
    
    int16_t* samples = wav_load(filename, &length);
    if (!samples) {
        printf("Failed to load WAV file: %s\n", filename);
        printf("Make sure the file is a valid WAV file\n");
        tr_destroy(track);
        return 1;
    }

    printf("Successfully loaded WAV file. Length: %zu samples\n", length);

    // 写入数据到音轨
    if (!tr_write(track, 0, length, samples)) {
        printf("Failed to write samples to track\n");
        free(samples);
        tr_destroy(track);
        return 1;
    }

    // 显示音轨长度
    printf("Track length: %zu samples\n", tr_length(track));

    // 读取部分数据并显示
    int16_t buffer[100];  // 读取前100个样本
    if (tr_read(track, 0, 100, buffer)) {
        printf("First 100 samples:\n");
        for (int i = 0; i < 10; i++) {  // 只显示前10个样本
            printf("%d ", buffer[i]);
        }
        printf("...\n");
    }

    // 清理资源
    free(samples);
    tr_destroy(track);
    return 0;
} 